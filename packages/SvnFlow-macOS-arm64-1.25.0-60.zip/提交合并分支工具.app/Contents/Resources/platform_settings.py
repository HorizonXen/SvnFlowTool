"""Load application settings without binding the merge engine to macOS defaults."""

from __future__ import annotations

import json
import os
import pathlib
import plistlib
import subprocess
import sys


LEGACY_BUNDLE_ID = "com.self.svnflow"


def default_config_path() -> pathlib.Path:
    override = os.environ.get("SVNFLOW_CONFIG")
    if override:
        return pathlib.Path(override).expanduser()
    if os.name == "nt":
        root = pathlib.Path(os.environ.get("APPDATA", pathlib.Path.home()))
        return root / "SvnFlow" / "config.json"
    root = pathlib.Path(os.environ.get("XDG_CONFIG_HOME", pathlib.Path.home() / ".config"))
    return root / "svnflow" / "config.json"


def _json_config() -> dict | None:
    path = default_config_path()
    if not path.is_file():
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"配置文件必须是 JSON 对象：{path}")
    return value


def _legacy_macos_config() -> dict | None:
    if sys.platform != "darwin":
        return None
    try:
        data = subprocess.check_output(
            ["defaults", "export", LEGACY_BUNDLE_ID, "-"],
            stderr=subprocess.DEVNULL,
        )
    except (OSError, subprocess.CalledProcessError):
        return None
    return plistlib.loads(data)


def load_config() -> dict:
    value = _json_config() or _legacy_macos_config()
    if value is None:
        raise RuntimeError(
            "未找到工作副本配置。请在应用中完成配置，或设置 SVNFLOW_CONFIG 指向配置 JSON。"
        )
    return value


def fixed_copies() -> list[dict]:
    value = load_config()
    copies = value.get("fixedCopies", value.get("SvnFlow.fixedCopies.v1"))
    if isinstance(copies, str):
        copies = json.loads(copies)
    if not isinstance(copies, list):
        raise RuntimeError("工作副本配置缺少 fixedCopies 数组。")
    required = {"id", "path"}
    if any(not isinstance(item, dict) or not required <= item.keys() for item in copies):
        raise RuntimeError("工作副本配置格式无效。")
    return copies
