"""Optional export integration is not included in the public build."""
def __getattr__(name):
    raise RuntimeError("此构建未包含可选的配置导出集成。")
